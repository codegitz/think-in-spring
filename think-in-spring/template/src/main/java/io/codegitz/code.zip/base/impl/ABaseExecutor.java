package io.codegitz.base.impl;

import io.codegitz.base.common.CommonBaseExecutor;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

/**
 * @author Codegitz
 * @date 2021/8/27 9:27
 **/
@Service("aBaseExecutorImpl")
@DependsOn("applicationUtils")
public class ABaseExecutor extends CommonBaseExecutor {
    @Override
    public String particularMethod(String name) {
        System.out.println(name + " invoke ABaseExecutorImpl#particularMethod()");
        return name + " invoke ABaseExecutorImpl#particularMethod()";
    }
}
